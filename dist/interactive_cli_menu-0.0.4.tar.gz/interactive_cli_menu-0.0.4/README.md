# interactive_CLI_menu

## **Under Construction!**

## Info

This is a library for creating menus in the console (CLI). There are four functions:
```
simple - Press **ENTER** to select an option
multi - Press **SPACE** to select an option, then press **ENTER** to confirm
mix - Same as multi, but with sliders. User **LEFT ARROW** and **RIGHT ARROW** to adjust the slider
amount - Press **SPACE** to select an option, then use **LEFT ARROW** and **RIGHT ARROW** to adjust the slider
```